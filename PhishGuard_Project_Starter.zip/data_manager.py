"""JSON persistence and retrieval. No CLI printing."""

import json
from pathlib import Path
from typing import Any


DATA_FILE = Path("data/reports.json")


def load_reports(path: Path = DATA_FILE) -> list[dict[str, Any]]:
    if not path.exists():
        return []

    try:
        with path.open("r", encoding="utf-8") as file:
            data = json.load(file)
    except json.JSONDecodeError as exc:
        raise ValueError("Data file is corrupt or contains invalid JSON.") from exc
    except OSError as exc:
        raise OSError("Unable to read the data file.") from exc

    if not isinstance(data, list):
        raise ValueError("Data file must contain a JSON list.")

    return data


def save_report(record: dict[str, Any], path: Path = DATA_FILE) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    reports = load_reports(path)
    from datetime import datetime

    record["created_at"] = datetime.now().isoformat(timespec="seconds")
    reports.append(record)

    temporary = path.with_suffix(".tmp")
    try:
        with temporary.open("w", encoding="utf-8") as file:
            json.dump(reports, file, indent=2, ensure_ascii=False)
        temporary.replace(path)
    except OSError as exc:
        raise OSError("Unable to save the data file.") from exc


def filter_reports(
    reports: list[dict],
    threat_level: str | None = None,
    attack_type: str | None = None,
    review_status: str | None = None,
) -> list[dict]:
    results = []
    for record in reports:
        ai = record.get("ai_analysis", {})
        triage = record.get("triage", {})
        if threat_level and ai.get("threat_level") != threat_level:
            continue
        if attack_type and ai.get("attack_type", "").lower() != attack_type:
            continue
        if review_status and triage.get("review_status") != review_status:
            continue
        results.append(record)
    return results


def get_report(reports: list[dict], report_id: str) -> dict | None:
    for record in reports:
        if record.get("report", {}).get("report_id") == report_id:
            return record
    return None


def update_report_record(
    reports: list[dict],
    report_id: str,
    updates: dict,
    path: Path = DATA_FILE,
) -> None:
    target = get_report(reports, report_id)
    if target is None:
        raise ValueError("Report ID not found.")

    triage = target.setdefault("triage", {})
    triage["review_status"] = updates["review_status"]

    if updates.get("priority_override"):
        triage["priority_override"] = updates["priority_override"]
        triage["final_priority"] = updates["priority_override"]

    if updates.get("investigation_notes") is not None:
        target["investigation_notes"] = updates["investigation_notes"]

    if updates.get("assigned_reviewer") is not None:
        target["assigned_reviewer"] = updates["assigned_reviewer"]

    temporary = path.with_suffix(".tmp")
    try:
        with temporary.open("w", encoding="utf-8") as file:
            json.dump(reports, file, indent=2, ensure_ascii=False)
        temporary.replace(path)
    except OSError as exc:
        raise OSError("Unable to save the updated report.") from exc
