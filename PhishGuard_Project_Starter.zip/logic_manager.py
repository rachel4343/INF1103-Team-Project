"""Deterministic validation and triage rules. No API calls or printing."""

from datetime import datetime, timedelta
from typing import Any


REQUIRED_FIELDS = {
    "threat_level",
    "attack_type",
    "confidence",
    "impersonation",
    "urgency_manipulation",
    "credential_request",
    "suspicious_link",
    "suspicious_attachment",
    "suspicious_domains",
    "impersonated_entity",
    "recommended_action",
    "evidence",
}

THREAT_LEVELS = {"low", "medium", "high"}
PRIORITY_ORDER = {"LOW": 0, "MEDIUM": 1, "HIGH": 2, "CRITICAL": 3, "MANUAL": 4}
URGENCY_ORDER = {"ROUTINE": 0, "PRIORITY": 1, "URGENT": 2, "IMMEDIATE": 3}


def validate_ai_response(data: dict[str, Any]) -> dict[str, Any]:
    if not isinstance(data, dict):
        raise ValueError("AI response must be a JSON object.")

    missing = REQUIRED_FIELDS - data.keys()
    if missing:
        raise ValueError(f"AI response missing fields: {sorted(missing)}")

    if data["threat_level"] not in THREAT_LEVELS:
        raise ValueError("Invalid threat_level.")

    if not isinstance(data["confidence"], (int, float)) or not 0 <= data["confidence"] <= 1:
        raise ValueError("confidence must be between 0 and 1.")

    boolean_fields = [
        "impersonation",
        "urgency_manipulation",
        "credential_request",
        "suspicious_link",
        "suspicious_attachment",
    ]
    if any(not isinstance(data[field], bool) for field in boolean_fields):
        raise ValueError("Indicator fields must be boolean.")

    if not isinstance(data["suspicious_domains"], list):
        raise ValueError("suspicious_domains must be a list.")

    if not isinstance(data["evidence"], list):
        raise ValueError("evidence must be a list.")

    return data


def _escalate_priority(current: str, new_value: str) -> str:
    return new_value if PRIORITY_ORDER[new_value] > PRIORITY_ORDER[current] else current


def _escalate_urgency(current: str, new_value: str) -> str:
    return new_value if URGENCY_ORDER[new_value] > URGENCY_ORDER[current] else current


def _base_triage(ai: dict) -> tuple[str, str]:
    if ai["threat_level"] == "high" and ai["confidence"] >= 0.80:
        return "HIGH", "URGENT"
    if ai["threat_level"] == "medium" and ai["confidence"] >= 0.75:
        return "MEDIUM", "PRIORITY"
    if ai["threat_level"] == "low" and ai["confidence"] >= 0.90 and not ai["suspicious_link"]:
        return "LOW", "ROUTINE"
    return "MEDIUM", "PRIORITY"


def _similar_report(new_ai: dict, new_report: dict, old_record: dict) -> bool:
    old_ai = old_record.get("ai_analysis", {})
    old_report = old_record.get("report", {})

    new_domains = set(new_ai.get("suspicious_domains", []))
    old_domains = set(old_ai.get("suspicious_domains", []))
    same_domain = bool(new_domains & old_domains)

    new_sender_domain = new_report.get("sender_email", "").split("@")[-1].lower()
    old_sender_domain = old_report.get("sender_email", "").split("@")[-1].lower()
    same_sender_domain = (
        bool(new_sender_domain)
        and new_sender_domain == old_sender_domain
    )

    same_attack = (
        new_ai.get("attack_type")
        and new_ai.get("attack_type") == old_ai.get("attack_type")
    )
    same_entity = (
        new_ai.get("impersonated_entity", "").strip().lower()
        and new_ai.get("impersonated_entity", "").strip().lower()
        == old_ai.get("impersonated_entity", "").strip().lower()
    )

    return same_domain or (same_sender_domain and same_attack) or (same_entity and same_attack)


def _within_window(old_record: dict, now: datetime, hours: int = 24) -> bool:
    timestamp = old_record.get("created_at")
    if not timestamp:
        return False
    try:
        old_time = datetime.fromisoformat(timestamp)
    except ValueError:
        return False
    return now - old_time <= timedelta(hours=hours) and old_time <= now


def _campaign_count(ai: dict, report: dict, previous_reports: list[dict], now: datetime) -> int:
    count = 0
    for record in previous_reports:
        if _within_window(record, now) and _similar_report(ai, report, record):
            count += 1
    return count


def determine_triage(
    ai: dict,
    report: dict,
    previous_reports: list[dict],
    now: datetime | None = None,
) -> dict[str, Any]:
    ai = validate_ai_response(ai)
    now = now or datetime.now()

    priority, urgency = _base_triage(ai)
    reasons: list[str] = []

    if ai["confidence"] < 0.70:
        return {
            "final_priority": "MANUAL",
            "response_urgency": "IMMEDIATE",
            "campaign_detected": False,
            "similar_report_count": 0,
            "escalation_reasons": ["AI confidence below 0.70; manual review required."],
            "review_status": "pending",
        }

    action = report.get("action_taken", "none")
    if action == "entered_credentials":
        priority = _escalate_priority(priority, "CRITICAL")
        urgency = _escalate_urgency(urgency, "IMMEDIATE")
        reasons.append("User entered credentials.")
    elif action in {"clicked_link", "opened_attachment"}:
        priority = _escalate_priority(priority, "HIGH")
        urgency = _escalate_urgency(urgency, "URGENT")
        reasons.append("User interacted with suspicious content.")

    similar_count = _campaign_count(ai, report, previous_reports, now)
    campaign_detected = similar_count >= 2

    if campaign_detected:
        priority = _escalate_priority(priority, "CRITICAL")
        urgency = _escalate_urgency(urgency, "IMMEDIATE")
        reasons.append(
            f"Potential campaign detected: {similar_count} similar reports in the last 24 hours."
        )

    if ai["credential_request"] and ai["suspicious_link"] and ai["confidence"] >= 0.80:
        priority = _escalate_priority(priority, "HIGH")
        urgency = _escalate_urgency(urgency, "URGENT")
        reasons.append("Credential request combined with suspicious link.")

    if ai["impersonation"] and ai["urgency_manipulation"] and ai["threat_level"] == "high":
        priority = _escalate_priority(priority, "HIGH")
        urgency = _escalate_urgency(urgency, "URGENT")
        reasons.append("High-risk impersonation and urgency indicators.")

    return {
        "final_priority": priority,
        "response_urgency": urgency,
        "campaign_detected": campaign_detected,
        "similar_report_count": similar_count,
        "escalation_reasons": reasons,
        "review_status": "pending",
    }
