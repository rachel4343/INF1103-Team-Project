# PhishGuard Engineering Report

## 1. Data Flow Diagram

```text
User Input
   |
   v
I/O Manager
- validate required fields
- normalise CLI input
   |
   v
AI Manager
- build API payload
- call AI API
- parse JSON
- validate AI schema
   |
   v
Logic Manager
- base risk
- user-impact escalation
- campaign correlation
- final priority and response urgency
   |
   +----------------------+
   |                      |
   v                      v
Data Manager          CLI Output
   |
   v
JSON File Storage
```

## 2. Exception Handling Matrix

| Failure | Detection | Handling | User/System Outcome |
|---|---|---|---|
| API connection failure | API request raises exception | Retry up to configured limit | Show error; no invalid AI result is stored |
| Malformed AI response | JSON/schema validation fails | Reject response and retry | Manual review/error path |
| Missing/corrupt data file | File missing or JSON decode fails | Missing file starts empty; corrupt file raises controlled error | No crash; user receives clear message |
| Invalid user input | Empty required input or invalid menu/action | Re-prompt | User remains in CLI until valid input |
| Invalid AI confidence/fields | Schema validation fails | Reject result | Prevents unsafe downstream business logic |

## 3. Core Business Logic

The Logic Manager is deliberately independent of the live AI API so that it can be tested deterministically.

The distinctive feature is context-aware triage. The system separates:
- threat risk: how suspicious the email appears;
- response urgency: how quickly security personnel should respond.

User actions can escalate urgency. Historical reports can trigger campaign detection when multiple similar reports occur within 24 hours. Escalation reasons are stored with the final decision.
