"""PhishGuard CLI entry point. Procedural architecture only."""

from io_manager import (
    collect_report,
    display_error,
    display_menu,
    display_report,
    display_reports,
    display_message,
    get_menu_choice,
    update_report_inputs,
)
from ai_manager import analyse_report
from logic_manager import determine_triage
from data_manager import (
    DATA_FILE,
    filter_reports,
    get_report,
    load_reports,
    save_report,
    update_report_record,
)


def create_report() -> None:
    """Collect, analyse, triage and persist one report."""
    report = collect_report()
    try:
        ai_result = analyse_report(report)
    except Exception as exc:
        display_error(f"AI service error: {exc}")
        display_message("The report was not automatically triaged. Please retry or use manual review.")
        return

    try:
        previous_reports = load_reports(DATA_FILE)
        triage = determine_triage(
            ai_result,
            report,
            previous_reports,
        )
        record = {
            "report": report,
            "ai_analysis": ai_result,
            "triage": triage,
        }
        save_report(record, DATA_FILE)
        display_message("Report analysed and saved successfully.")
        display_report(record)
    except (ValueError, OSError, json.JSONDecodeError) as exc:
        display_error(f"Could not process or save the report: {exc}")


def list_reports() -> None:
    reports = load_reports(DATA_FILE)
    display_reports(filter_reports(reports))


def search_reports() -> None:
    reports = load_reports(DATA_FILE)
    threat = input("Threat level filter (low/medium/high or blank): ").strip().lower()
    status = input("Review status filter (pending/investigating/resolved or blank): ").strip().lower()
    attack_type = input("Attack type filter or blank: ").strip().lower()
    results = filter_reports(
        reports,
        threat_level=threat or None,
        review_status=status or None,
        attack_type=attack_type or None,
    )
    display_reports(results)


def view_report() -> None:
    report_id = input("Enter report ID: ").strip()
    record = get_report(load_reports(DATA_FILE), report_id)
    if record:
        display_report(record)
    else:
        display_error("Report ID not found.")


def update_report() -> None:
    records = load_reports(DATA_FILE)
    report_id = input("Enter report ID to update: ").strip()
    record = get_report(records, report_id)
    if not record:
        display_error("Report ID not found.")
        return

    updates = update_report_inputs(record)
    try:
        update_report_record(records, report_id, updates, DATA_FILE)
        display_message("Report updated successfully.")
    except (ValueError, OSError) as exc:
        display_error(str(exc))


def main() -> None:
    while True:
        display_menu()
        choice = get_menu_choice()
        if choice == "1":
            create_report()
        elif choice == "2":
            list_reports()
        elif choice == "3":
            search_reports()
        elif choice == "4":
            view_report()
        elif choice == "5":
            update_report()
        elif choice == "6":
            display_message("Goodbye.")
            break


if __name__ == "__main__":
    main()
