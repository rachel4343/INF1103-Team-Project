"""All CLI input, output, validation and formatting lives here."""

from uuid import uuid4


def display_menu() -> None:
    print("\n=== PhishGuard ===")
    print("1. Submit suspicious-email report")
    print("2. List reports")
    print("3. Search/filter reports")
    print("4. View report")
    print("5. Update report status/priority/notes")
    print("6. Exit")


def get_menu_choice() -> str:
    while True:
        choice = input("Select an option: ").strip()
        if choice in {"1", "2", "3", "4", "5", "6"}:
            return choice
        print("Invalid choice. Enter 1-5.")


def prompt_required(label: str) -> str:
    while True:
        value = input(f"{label}: ").strip()
        if value:
            return value
        print(f"{label} is required.")


def prompt_list(label: str) -> list[str]:
    value = input(f"{label} (comma-separated, blank if none): ").strip()
    if not value:
        return []
    return [item.strip() for item in value.split(",") if item.strip()]


def prompt_action() -> str:
    valid = {
        "none": "none",
        "opened": "opened_attachment",
        "clicked": "clicked_link",
        "credentials": "entered_credentials",
    }
    while True:
        print("Action taken: none / opened / clicked / credentials")
        value = input("Action: ").strip().lower()
        if value in valid:
            return valid[value]
        print("Invalid action. Choose none, opened, clicked or credentials.")


def collect_report() -> dict:
    print("\n--- New Suspicious Email Report ---")
    return {
        "report_id": str(uuid4())[:8],
        "sender_email": prompt_required("Sender email address"),
        "sender_display_name": input("Sender display name (optional): ").strip(),
        "subject": prompt_required("Email subject"),
        "email_content": prompt_required("Email content"),
        "links": prompt_list("Links"),
        "attachments": prompt_list("Attachments"),
        "reason_for_suspicion": prompt_required("Reason for suspicion"),
        "action_taken": prompt_action(),
    }


def display_report(record: dict) -> None:
    report = record["report"]
    ai = record["ai_analysis"]
    triage = record["triage"]

    print("\n--- Report ---")
    print(f"ID: {report['report_id']}")
    print(f"Sender: {report['sender_display_name']} <{report['sender_email']}>")
    print(f"Subject: {report['subject']}")
    print(f"Action taken: {report['action_taken']}")
    print(f"Threat level: {ai['threat_level']}")
    print(f"Attack type: {ai['attack_type']}")
    print(f"Confidence: {ai['confidence']:.2f}")
    print(f"Final priority: {triage['final_priority']}")
    print(f"Response urgency: {triage['response_urgency']}")
    print(f"Campaign detected: {triage['campaign_detected']}")
    print(f"Reasons: {'; '.join(triage['escalation_reasons']) or 'Base triage only'}")
    print(f"Recommended action: {ai['recommended_action']}")


def display_reports(records: list[dict]) -> None:
    print(f"\n--- Reports ({len(records)}) ---")
    if not records:
        print("No reports found.")
        return
    for record in records:
        report = record["report"]
        ai = record["ai_analysis"]
        triage = record["triage"]
        print(
            f"{report['report_id']} | {ai['threat_level'].upper()} | "
            f"{triage['final_priority']} | {ai['attack_type']} | {report['subject']}"
        )


def update_report_inputs(record: dict) -> dict:
    print("\n--- Update Report ---")
    print("1. pending")
    print("2. investigating")
    print("3. resolved")
    status_map = {"1": "pending", "2": "investigating", "3": "resolved"}
    while True:
        choice = input("Review status: ").strip()
        if choice in status_map:
            break
        print("Invalid status choice.")

    override = input(
        "Priority override (LOW/MEDIUM/HIGH/CRITICAL or blank to keep current): "
    ).strip().upper()
    if override and override not in {"LOW", "MEDIUM", "HIGH", "CRITICAL"}:
        print("Invalid priority override; current priority will be kept.")
        override = ""

    notes = input("Investigation notes (blank to keep current): ").strip()
    reviewer = input("Assigned reviewer (blank to keep current): ").strip()

    return {
        "review_status": status_map[choice],
        "priority_override": override or None,
        "investigation_notes": notes or None,
        "assigned_reviewer": reviewer or None,
    }


def display_message(message: str) -> None:
    print(message)


def display_error(message: str) -> None:
    print(f"ERROR: {message}")
