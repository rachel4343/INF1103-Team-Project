import unittest
from datetime import datetime, timedelta

from logic_manager import determine_triage, validate_ai_response


def sample_ai(**overrides):
    data = {
        "threat_level": "high",
        "attack_type": "credential_phishing",
        "confidence": 0.91,
        "impersonation": True,
        "urgency_manipulation": True,
        "credential_request": True,
        "suspicious_link": True,
        "suspicious_attachment": False,
        "suspicious_domains": ["evil-login.example"],
        "impersonated_entity": "Microsoft",
        "recommended_action": "Security investigation",
        "evidence": ["Urgent account verification request"],
    }
    data.update(overrides)
    return data


def sample_report(**overrides):
    data = {
        "report_id": "TEST001",
        "sender_email": "notice@evil-login.example",
        "sender_display_name": "Microsoft Security",
        "subject": "Urgent verification",
        "email_content": "Verify your account immediately.",
        "links": ["https://evil-login.example/login"],
        "attachments": [],
        "reason_for_suspicion": "Suspicious login request",
        "action_taken": "none",
    }
    data.update(overrides)
    return data


class LogicManagerTests(unittest.TestCase):
    def test_valid_ai_response(self):
        result = validate_ai_response(sample_ai())
        self.assertEqual(result["threat_level"], "high")

    def test_invalid_confidence_rejected(self):
        with self.assertRaises(ValueError):
            validate_ai_response(sample_ai(confidence=1.5))

    def test_low_confidence_requires_manual_review(self):
        result = determine_triage(
            sample_ai(confidence=0.50),
            sample_report(),
            [],
            datetime(2026, 10, 1, 10, 0),
        )
        self.assertEqual(result["final_priority"], "MANUAL")

    def test_credentials_entered_escalates_to_critical(self):
        result = determine_triage(
            sample_ai(),
            sample_report(action_taken="entered_credentials"),
            [],
            datetime(2026, 10, 1, 10, 0),
        )
        self.assertEqual(result["final_priority"], "CRITICAL")
        self.assertEqual(result["response_urgency"], "IMMEDIATE")

    def test_campaign_detection(self):
        now = datetime(2026, 10, 1, 10, 0)
        old1 = {
            "created_at": (now - timedelta(hours=1)).isoformat(),
            "report": sample_report(report_id="OLD1"),
            "ai_analysis": sample_ai(),
            "triage": {},
        }
        old2 = {
            "created_at": (now - timedelta(hours=2)).isoformat(),
            "report": sample_report(report_id="OLD2"),
            "ai_analysis": sample_ai(),
            "triage": {},
        }
        result = determine_triage(
            sample_ai(),
            sample_report(),
            [old1, old2],
            now,
        )
        self.assertTrue(result["campaign_detected"])
        self.assertEqual(result["final_priority"], "CRITICAL")

    def test_old_report_does_not_trigger_campaign(self):
        now = datetime(2026, 10, 1, 10, 0)
        old = {
            "created_at": (now - timedelta(hours=30)).isoformat(),
            "report": sample_report(report_id="OLD"),
            "ai_analysis": sample_ai(),
            "triage": {},
        }
        result = determine_triage(
            sample_ai(),
            sample_report(),
            [old, old],
            now,
        )
        self.assertFalse(result["campaign_detected"])


if __name__ == "__main__":
    unittest.main()
