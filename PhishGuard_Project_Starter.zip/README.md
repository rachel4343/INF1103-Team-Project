# PhishGuard – AI-Powered Phishing Report Triage System

## Purpose
PhishGuard is a procedural CLI application for initial triage of user-reported suspicious emails.

The AI interprets unstructured email information and returns structured phishing indicators. The Logic Manager then applies deterministic rules using:
1. AI risk indicators and confidence
2. User impact/actions
3. Historical report patterns
4. Campaign detection

The system supports human cybersecurity review; it does not provide a definitive forensic verdict.

## Architecture
- `main.py` — orchestration only
- `io_manager.py` — all CLI input/output and validation
- `ai_manager.py` — AI API call, prompt construction, JSON parsing and schema validation
- `logic_manager.py` — deterministic business rules and unique context-aware triage
- `data_manager.py` — JSON persistence and filtering
- `tests/test_logic_manager.py` — API-independent automated tests

## Run locally
```powershell
python -m venv .venv
.\.venv\Scripts\Activate.ps1
pip install -r requirements.txt
$env:OPENAI_API_KEY="your-key"
python main.py
```

## Run tests
```powershell
PYTHONPATH=. python -m unittest discover -s tests -v
```

Tests use hardcoded AI responses and do not call the live API.

## Docker
```powershell
docker build -t phishguard .
docker run --rm -it -e OPENAI_API_KEY=$env:OPENAI_API_KEY -v "${PWD}/data:/app/data" phishguard
```

## Unique business-rule feature
PhishGuard performs context-aware triage. A report can be escalated because:
- the user clicked a suspicious link or entered credentials;
- multiple similar reports appear within 24 hours;
- repeated indicators suggest a coordinated phishing campaign;
- the final decision records explicit escalation reasons.
